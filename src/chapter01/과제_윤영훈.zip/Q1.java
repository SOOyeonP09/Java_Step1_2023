package chapter01;

public class Q1 {

	public static void main(String[] args) {
		
		byte aNum = 10;
		int bNum = aNum;     
		
		float cNum = 3.14f;
		double dNum = cNum;
		
		System.out.println("Byte : " +aNum);
		System.out.println("Int : " +bNum);
		System.out.println("Float : " +cNum);
		System.out.println("Double : " +dNum);
		
	}
}
