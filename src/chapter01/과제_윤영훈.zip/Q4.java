package chapter01;

public class Q4 {
	public static void main(String[] args) {
		
		int i = 10;
        float j = 2.5f;
        
        System.out.println("Num1 : "+i +", Num2 : " + j);
        System.out.println("add : " + (int)(i+j));
        System.out.println("sub : " + (int)(i-j));
        System.out.println("mul : " + (int)(i*j));
        System.out.println("div : " + (int)(i/j));
	}

}
