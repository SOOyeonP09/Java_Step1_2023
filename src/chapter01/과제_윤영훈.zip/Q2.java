package chapter01;

public class Q2 {

	public static void main(String[] args) {
		
		float eNum = 1.2f;
		int fNum = (int)eNum;
		
		float  gNum = 2.5f;
		int hNum = (int)gNum;
		
		System.out.println("실수형 " + eNum + " 에서 정수형 " + fNum);
		System.out.println("실수형 " + gNum + " 에서 정수형 " + hNum);
	}
}
