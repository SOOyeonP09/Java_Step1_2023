package chapter01;

public class Q5 {
	public static void main(String[] args) {
		
		char a = '글';
        char b = '\uAE00';
        
        System.out.println(a);
        System.out.println(b);
	}

}
