package chapter01;

public class Q3 {

		public static void main(String[] args) {

			// 부동소수점 방식
			
			
		}
}
